import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PostController } from './post.controller';
import { PostService } from './providers/post.service';
import { PostEntity } from './post.entity';
import { MetaOption } from 'src/meta-options/entities/meta-option.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PostEntity, MetaOption])],
  controllers: [PostController],
  providers: [PostService],
  exports: [TypeOrmModule],  // Make PostService available to other modules for dependency injection.  // You can now use this service in other modules.  // This is especially useful when you have a module that needs to use a service provided by another module.  // In this case, PostModule can import PostService from the MetaOptionsModule, and then use it in its own controllers.  // This way, the PostService can be injected and used in PostModule without needing
})
export class PostModule {}