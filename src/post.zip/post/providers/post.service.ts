import { Body, Injectable } from '@nestjs/common';
import { PostEntity } from '../post.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MetaOption } from 'src/meta-options/entities/meta-option.entity';
import { CreatePostDto } from '../post.dto/createPost.dto';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class PostService {
  constructor(
    @InjectRepository(MetaOption)
    private readonly metaOptionRepository: Repository <MetaOption>,

    @InjectRepository(PostEntity)
    private readonly postRepository: Repository <PostEntity>
  ){}

  // Get all posts
  async getAllPosts(): Promise<PostEntity[]> {
    return await this.postRepository.find();
  }
  // async get single post
  async getPostById(id): Promise<PostEntity | undefined> {
    return await this.postRepository.findOne(id);
  }

  //Delete a single post
  // async deletePost(id: number) {
  //   //find the post by id
  //   const post = await this.postRepository.findOneBy({id})
  //   if (!post) {
  //     throw new NotFoundException(`Post with id ${id} not found.`);
  //   };

  //   const inversePost = await this.metaOptionRepository.find({

  //     where: { id: post.metaOption.id },
  //     relations: {post: true}
  //   });

  //   return {delete: true, id}
    
  //   // //check if the post exists before deleting it
  //   // if (!post) {
  //   //   throw new NotFoundException(`Post with id ${id} not found.`);
  //   // }
  //   // //delete the post
  //   // await this.postRepository.remove(post);
  //   // //find the metaOption of the post
  //   // if(post.metaOption){
  //   //   await this.metaOptionRepository.delete(post.metaOption.id);
  //   // }
  //   // //delete the post from the database
  //   // await this.postRepository.delete(id);
    
  // }

  //Create a new post
  async createPost(createPostDto: CreatePostDto) {
    const { metaOptions,...postData } = createPostDto;
    // Perform any necessary data transformation or validation here before saving to the database.
    const post = this.postRepository.create(postData);
    
    if (metaOptions) {
      const metaOption = await this.metaOptionRepository.save(metaOptions);
      post.metaOption = metaOption;
    }
    return await this.postRepository.save(post);
}

async deletePost(id) {
  // Find the post by id
  const post = await this.postRepository.findOneBy(id);

  if (!post) {
    throw new NotFoundException(`Post with id ${id} not found.`);
  }

  // Check if the post has a metaOption
  if (post.metaOption) {
    // Delete the metaOption
    await this.metaOptionRepository.delete(post.metaOption.id);
  }

  // Delete the post
  await this.postRepository.delete(id);
  return { deleted: true, id, message: 'Post deleted successfully.' };
}
}
