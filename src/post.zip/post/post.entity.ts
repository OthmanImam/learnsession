import { Entity, PrimaryGeneratedColumn, Column, JoinColumn, OneToOne } from 'typeorm';
import { PostType } from './enums/postType.enums';
import { postStatus } from './enums/postStatus.enum';
import { MetaOption } from 'src/meta-options/entities/meta-option.entity';

@Entity()
export class PostEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: false,
  })
  title: string;

  @Column({
    type: 'text',
    nullable: false,
  })
  content: string;
  
  @Column({
    enum: PostType,
    nullable: false,
    default: PostType.SCIENCE,
  })
  postType: PostType;
  
  @Column({
    type: 'enum', enum:postStatus
  })
  postStatus: postStatus;
  
  @OneToOne(()=>MetaOption, (metaOption)=> metaOption.post, {cascade: true, eager: true})
  metaOption?: MetaOption;

}