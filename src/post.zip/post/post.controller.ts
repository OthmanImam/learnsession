import { Controller, Get, Post, Body, Param, Delete } from '@nestjs/common';
import { PostService } from './providers/post.service';
import { PostEntity } from './post.entity';
import { CreatePostDto } from './post.dto/createPost.dto';

@Controller('posts')
export class PostController {
  constructor(private readonly postService: PostService) {}
 
  @Get()
  async getAllPosts(): Promise<PostEntity[]> {
    return this.postService.getAllPosts();
  }

  @Get(':id')
  async getPostById(@Param('id') id): Promise<PostEntity | undefined> {
    return this.postService.getPostById(id);
  }
  @Post()
  async createPost(@Body() createPostDto: CreatePostDto): Promise<PostEntity> {
    return this.postService.createPost(createPostDto);
  }

  @Delete(':id')
  async deletePost(@Param('id') id: number): Promise<void> {
    await this.postService.deletePost(id);
  }
}