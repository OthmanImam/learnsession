// import { Controller, Get, Post, Put, ParseIntPipe } from '@nestjs/common';
import { Controller,Delete, Get, Post, Put, ParseIntPipe, Param, Query, Body, Headers, DefaultValuePipe, Patch } from '@nestjs/common';
import { DeleteUserDTO } from 'src/users/dots/deleteUser.dto';
import { GetUserParamsDTO } from 'src/users/dots/getUser.paramsDto';
import { UserDto } from 'src/users/dots/user.dto';
import { UserService } from './providers/user.services';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';

 
@Controller('users')
  @ApiTags('Users')
export class UsersController {
    constructor(private readonly userService: UserService) {}
    @ApiOperation({
        summary: 'Fetch users',
    })
    @ApiResponse({
        description: 'List of users',
        status: 200,
        type: [UserDto],
    })
    @Get('/:id?')
    @ApiQuery({
        name: 'limit',
        description: 'The id of the user',
        required: false,
        type: Number,
    })
    public getUser(
        @Param() getUserParamDTO: GetUserParamsDTO,
        @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number | undefined,
        @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    ): any {
      
        return this.userService.findById(getUserParamDTO.id)
    }
    @Get('/')
    public getAllUsers(
        @Param() getUserParamDTO: GetUserParamsDTO,
        @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number | undefined,
        @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    ): any {
      
        return this.userService.findAll(getUserParamDTO, limit, page)
    }
    
    @Post()
    public postUsers(
        @Body() createUserDto: UserDto,
    ): any {
        console.log(createUserDto);
        return createUserDto.hashPassword().then((hashedPassword) => ({...createUserDto, password: hashedPassword }));
    }

    @Put()
    public putUsers(): any {
        return 'You have updated a user';
    }

    //Patch
    @Patch()
    public editUsers(
        @Body() updateUserDto: UserDto,
        @Headers() userId: string,
    ): any {
        console.log(updateUserDto);
        console.log(userId);
        return updateUserDto.hashPassword().then((hashedPassword) => ({...updateUserDto, password: hashedPassword }));
        // return 'You have patched a user';
    }

    @Delete(':id')
    public deleteUsers(
        @Param() id: DeleteUserDTO,
    ): any {
        console.log(id);
        return `User ${id} has been deleted`;
    }

    //Delete
}