import { Module } from '@nestjs/common';
import { UsersController } from './users.controller';
import { UserService } from './providers/user.services';

@Module({
    controllers: [UsersController],
    providers: [UserService], // Add the UserService to the providers array
    imports: [],
    exports: [UserService], // Make the UserService available for other modules
})
export class UsersModule {}