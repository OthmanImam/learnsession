import { IsStrongPassword, Matches, IsEmail } from 'class-validator';
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { PostEntity } from '../post/post.entity';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: false,
  })
  firstName: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  lastName: string;

  @Column({
    type: 'varchar',
    length: 255,
    unique: true,
    nullable: false,
  })
  email: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: false,
  })
  @IsStrongPassword()
  @Matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d){8,}$/,
    { message: 'Password should be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.' }
  )
  password: string;

  @OneToMany(() => PostEntity, post => post.user)
  posts: PostEntity[];

}