import { IsNotEmpty } from "class-validator";

//Delete User
export class DeleteUserDTO {
    @IsNotEmpty()
    id: Number;
}