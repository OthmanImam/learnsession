import { Injectable } from '@nestjs/common';
import { GetUserParamsDTO } from '../dots/getUser.paramsDto';

@Injectable()
export class UserService {
    public findAll (
        getUserDTO: GetUserParamsDTO, 
        limit: number, 
        page: number) {
            return [
                {
                    firstName: 'John',
                    lastName: 'Doe',
                    email: 'johndoe@example.com',
                    password: 'password',
                    confirmPassword: true
                },
                {
                    firstName: 'Jane',
                    lastName: 'Doe',
                    email: 'janedoe@example.com',
                    password: 'password',
                    confirmPassword: true
                }
            ]
        }

        public findById (id: number) {
            return {
                firstName: 'John',
                lastName: 'Doe',
                email: 'johndoe@example.com',
                password: 'password',
                confirmPassword: true
            };
        }
}