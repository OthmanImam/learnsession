import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { PostService } from './post/providers/post.service';
import { PostModule } from './post/post.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './users/user.entity';
import { PostEntity } from './post/post.entity';
import { UserService } from './users/providers/user.services';

@Module({
  imports: [
    UsersModule,
    PostModule,
    TypeOrmModule.forRootAsync({
      useFactory: () => ({
        type: 'postgres',
        host: 'localhost',
        port: 5432,
        username: 'postgres',
        password: 'BNG482@AA',
        database: 'learning',
        entities: [PostEntity, User],
        synchronize: true,
        import: [],
        inject: []
      })
    }),
  ],
  controllers: [AppController],
  providers: [AppService, PostService, UserService],
})
export class AppModule {}