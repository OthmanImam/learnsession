import { Injectable } from '@nestjs/common';
import { PostEntity } from '../post.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class PostService {

    findAllPosts(){
        return [
            {title: 'First Post', content: 'This is the first post.'},
            {title: 'Second Post', content: 'This is the second post.'}
        ];
    }
    
    createPost(){
        return {
            "title": "Sample Post",
            "content": "This is a sample post content.",
            "postType": "NEWS",
            "postStatus": "PUBLISHED",
            "imageUrl": "https://example.com/image.jpg",
            "publishedDate": "2022-01-01T12:00:00Z",
            "tags": ["sample", "post"],
            "author": {
              "id": 1,
              "name": "John Doe",
              "email": "john.doe@example.com"
    }
}}
}
