import { Controller, Get, Post, Body } from '@nestjs/common';
import { PostService } from './providers/post.service';
import { PostEntity } from './post.entity';

@Controller('posts')
export class PostController {
  constructor(private readonly postService: PostService) {}

  @Get()
  async findAllPosts() {
    return await this.postService.findAllPosts();
  }

  @Post()
  async createPost(@Body() postData: Partial<PostEntity>) {
    const post = await this.postService.createPost();
    return { message: 'Post created successfully', post };
  }
}