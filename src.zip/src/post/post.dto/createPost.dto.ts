import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsEnum, IsDate, IsArray, ValidateNested, MinLength, IsOptional, IsISO8601 } from 'class-validator';
import { PostType } from '../enums/postType.enums';
import { postStatus } from '../enums/postStatus.enum';
import { UserDto } from 'src/users/dots/user.dto';

export class CreatePostDto {

  @ApiProperty({ description: 'The title of the post' })
  @IsString()
  @MinLength(4)
  @IsNotEmpty()
  title: string;

  @ApiProperty({ description: 'The content of the post' })
  @IsString()
  @IsNotEmpty()
  content: string;

  @ApiProperty({description: 'The type of the post',})
  @IsEnum(PostType)
  @IsNotEmpty()
  postType: PostType;

  @ApiProperty({ description: 'The status of the post' })
  @IsEnum(postStatus)
  postStatus: postStatus;

  @ApiProperty({ description: 'The URL of the post image' })
  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  imageUrl: string;

  @ApiProperty({ description: 'The published date of the post' })
  @IsDate()
  @IsISO8601()
  publishedDate: Date;

  @ApiProperty({ description: 'The tags of the post' })
  @IsArray()
  @IsString({ each: true })
  tags: string[];

  // @ApiProperty({ description: 'The author of the post' })
  // @ValidateNested()
  // @IsEnum(UserDto)
  // author: UserDto;
}