import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from '../users/user.entity';
import { PostType } from './enums/postType.enums';
import { postStatus } from './enums/postStatus.enum';

@Entity()
export class PostEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: false,
  })
  title: string;

  @Column({
    type: 'text',
    nullable: false,
  })
  content: string;
  
  @Column({
    enum: PostType
  })
  postType: PostType;
  
  @Column({
    type: 'enum', enum:postStatus
  })
  postStatus: postStatus;

  @ManyToOne(() => User, user => user.posts)
  user: User;
}