import { Injectable } from '@nestjs/common';
import { GetUserParamDto } from '../dto/get-usersParam.dto';
import { CreateUserDto } from '../dto/create-user.dto';
import { User } from '../user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
// Any communication to the dataBase must come from the services

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
  ) {}

  public async createUser(createUserDto : CreateUserDto) { 
     // checks if a user exists in your application
   const existingUser =  await this.usersRepository.findOne({
        where: {email: createUserDto.email}
   })

   //  Create new User
      let newUser = this.usersRepository.create(createUserDto)
      newUser = await this.usersRepository.save(newUser)
      return newUser
  }

  public async getUser(
    getUserParamDto: GetUserParamDto, id: number
  ): Promise<User> {
    return await this.usersRepository.findOne({});
  }

  // findAll(): Promise<User[]> {
  //   return this.usersRepository.find();
  // }

  // findOne(id: number): Promise<User | null> {
  //   return this.usersRepository.findOneBy({ id });
  // }

  // async remove(id: number): Promise<void> {
  //   await this.usersRepository.delete(id);
  // }
}

