import { Injectable } from '@nestjs/common';
import { UpdateMetaOptionDto } from './dto/update-meta-option.dto';
import { CreatePostMetaOptionsDto } from './dto/create-meta-option.dto';

@Injectable()
export class MetaOptionsService {
  create(createMetaOptionDto: CreatePostMetaOptionsDto) {
    return 'This action adds a new metaOption';
  }

  findAll() {
    return `This action returns all metaOptions`;
  }

  findOne(id: number) {
    return `This action returns a #${id} metaOption`;
  }

  update(id: number, updateMetaOptionDto: UpdateMetaOptionDto) {
    return `This action updates a #${id} metaOption`;
  }

  remove(id: number) {
    return `This action removes a #${id} metaOption`;
  }
}
